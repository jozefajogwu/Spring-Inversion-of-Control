/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package springdemo1;

/**
 *
 * @author ajogwu
 */
class BadmintonCoach implements Coach {

    @Override
    public String getDailyworkout() {
        return "Played Badminton very well";
    }
    
}
