/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package springdemo1;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author ajogwu
 */
public class HelloSpringApp {

    public static void main(String[] args) {

        //LOAD THE SPRING CONFIGURATION FILE
        ClassPathXmlApplicationContext context
                = new ClassPathXmlApplicationContext("springdemo1/applicationContext.xml");

        // RETRIEVE BEAN FROM  SPRING CONTAINER
        Coach theCoach = context.getBean("myCoach", Coach.class);

        //CALL METHODS ON THE BEAN
        System.out.println(theCoach.getDailyworkout());

        //CLOSE THE APPLICATION CONTEXT
        context.close();
    }

}
